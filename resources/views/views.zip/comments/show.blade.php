@extends('layouts.app')

@section('title', 'Posts')

@section('main')

Show

@endsection
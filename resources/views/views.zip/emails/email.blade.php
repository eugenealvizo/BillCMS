<!DOCTYPE html>
<html>
	<head>
		<title>Camaya Inquiry</title>
	</head>
	<body>
		<h1></h1>
		{!!$content!!}
	</body>
</html>
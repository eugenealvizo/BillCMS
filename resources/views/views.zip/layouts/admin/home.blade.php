@extends('admin')
@section('title')
	<title>Camaya Admin CMS</title>
@endsection
@section('content')
    {{csrf_field()}}
<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Homepage Contents</h1>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <h2>Banners</h2><a href="{{url('/admin/dashboard/update/banners')}}" class="">Update</a> | <a href="javascript:void(0)" class="banner-toggle">Enable {{$is_video == 0 ? 'Video Banner' : 'Image Banner'}}</a>
    </div>
</div>
<br>

@if($is_video == 0)
<div id="banners-container">
    @foreach($banners as $banner) 
    <img src="{{url('/uploads/home/banners/'.$banner)}}" height="250px" width="300px">
    @endforeach
</div>
@else 
<div id="video-container">
    <div class="row">
        <iframe width="854" height="480" src="{{$utube}}" frameborder="0" allowfullscreen></iframe>
    </div>
    <form id="addForm" method="POST" enctype="multipart/form-data">

        <div class="row">
            <div class="col-sm-3"></div>
            <div class="col-sm-3">
                <div class="form-group">
                    <input type="text" name="url" id="url" class="form-control req"/>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="form-group">
                    <button  class="btn btn-primary btn-sub" id="change-vid">Submit</button>
                </div>
            </div>
        </div>
    </form>
</div>
@endif


<div class="row">
    <div class="col-md-6">
        <h2>Image Reel</h2><a href="{{url('/admin/dashboard/update/images')}}" class="">Update</a>
    </div>
</div>
<br>
@foreach($images as $image) 
<img src="{{url('/uploads/home/images/'.$image)}}" height="250px" width="300px">
@endforeach


@endsection


@extends('admin')
@section('title')
    <title>CMS</title>
@endsection

@section('content')

<div class="row">
    <div class="col-lg-12">
        <h1 class="page-header">Rooms<small></small></h1><a href="{{url('/')}}/admin/{{Request::segment(2)}}/rooms/insert"> <i class="fa fa-plus-circle" aria-hidden="true"></i> Add New</a>
    </div>
</div>
<br>
<table class="table">
    <thead>
        <tr>
        <th>Title</th>
        <th>Actions</th>
        </tr>
    </thead>
    <tbody>
    @foreach($rooms as $room)
        <tr>    
            <td>{{$room->title}}</td>
            <td>
                <a href="{{url('/')}}/admin/places-to-stay/rooms/images/insert/{{$room->id}}" class="btn btn-default">Images</a>
                <a href="{{url('/')}}/admin/places-to-stay/rooms/update/{{$room->id}}" class="btn btn-default">Update</a>
                <button type="button" class="btn btn-default">Delete</button>
            </td>
        </tr>
    @endforeach
    </tbody>
</table>
@endsection


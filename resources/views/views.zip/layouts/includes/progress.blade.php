<div id="progress">
	<div class="progress-wrap">
		<div class="progress-container">
			<div class="img-wrap">
				<img src="dist/images/default.gif" alt="">
			</div>
			<div class="progress-bar"></div>
			<div class="progress-percent">0 %</div>
		</div>
	</div>
</div>
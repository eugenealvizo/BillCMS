<div class="pop-cover">
  <div class="pop-holder"></div>
   <div class="close-tablet">
      <?php include('dist/images/close.svg'); ?>
    </div>
  <div class="pop-up popsearch">
    <div class="close">
      <?php include('dist/images/close.svg'); ?>
    </div>
    <div class="search-holder">
      <input type="search" placeholder="TYPE HERE">

      <div class="suggestions">
        <span>Search Suggestions...</span>
        <div class="suggested-search">
          <a href="javascript:void(0);">
            Discounted Accomodations
          </a>
          <a href="javascript:void(0);">
            Family Discounts
          </a>
        </div>
      </div>
    </div>
  </div>  
</div>

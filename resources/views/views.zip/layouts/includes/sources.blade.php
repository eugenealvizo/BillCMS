<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"/>
	<!-- FONTS -->
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,600,300,800' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Merriweather:400,300,700,900' rel='stylesheet' type='text/css'>
	<link href="https://fonts.googleapis.com/css?family=Oswald:300,400,700|Quicksand:300,400,700" rel="stylesheet">
	<!-- VENDOR -->
	<link rel="stylesheet" type="text/css" href="{{url('dist/css/vendor/slick.css')}}">
  	<link rel="stylesheet" type="text/css" href="{{url('dist/css/vendor/slick-theme.css')}}">
  	<link rel="stylesheet" type="text/css" href="{{url('dist/css/vendor/DateTimePicker.css')}}">
  	<link rel="stylesheet" type="text/css" href="{{url('dist/css/vendor/jquery.mb.YTPlayer.min.css')}}">

	
	<link rel="stylesheet" type="text/css" href="{{url('dist/css/mainstyle.css')}}" />
	
	
	<meta name="theme-color" content="#f9a728">
	<title></title>
